<?php $__env->startSection('pageTitle', 'Thèses '.$axe); ?>


<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Outputs / Thèses</p>
                <i class="bi bi-circle text-white px-2"></i>
                <h3 class="text-white animated zoomIn">
                    <span class="text-warning">

            </div>
        </div>
    </div>
    </div>
    <div class="section-title text-center position-relative pb-3 mb-4 mx-auto bg-white p-4 rounded" style="max-width: 600px;">
        <h1 class="mb-0">Thèses</h1>
    </div>
    <div class="container">
        
        
        <?php if(empty(!$theses)): ?>
            <div class="row">
                <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $these): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 wow zoomIn" data-wow-delay="0.3s"
                        style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                        <div
                            class="service-item bg-light  d-flex flex-column align-items-center justify-content-center text-center border border-3">
                            <div class="service-icon">
                                <i class="fa fa-graduation-cap text-white fs-3"></i>
                            </div>
                            <h5 class="mb-1"><?php echo e($these->titre); ?></h5>
                            <hr class="w-50 mx-auto bg-dark">
                            <span class="text-dark fw-bold"> Auteur: <a class=""
                                    href=""><?php echo e($these->auteur); ?></a></span>
                            <a class="btn btn-sm btn-outline-danger p-3 mt-1 rounded  py-0"
                                href="<?php echo e(url('storage/' . $these->fichier)); ?>">
                                <i class="fa fa-file-pdf-o "></i> PDF
                            </a>
                        </div>
                        <div class="accordion mb-2" id="acc<?php echo e($these->id); ?>">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button text-dark" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse<?php echo e($these->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                        Encadrants
                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($these->id); ?>" class="accordion-collapse collapse shoew" aria-labelledby="headingOne"
                                    data-bs-parent="#acc<?php echo e($these->id); ?>">
                                    <ul class="accordion-body list-group ms-2">
                                        <?php $__currentLoopData = $these->encadrants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encadrant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item"><a
                                                    href="<?php echo e(route('equipes', ['type' => $encadrant->typeChercheur])); ?>#<?php echo e(urlencode($encadrant->full_name)); ?>"
                                                    class="text-dark mb-0"><?php echo e($encadrant->full_name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        <?php else: ?>
            <span class="text-italic">Pas de thèses pour le moment</span>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/outputs/theses.blade.php ENDPATH**/ ?>