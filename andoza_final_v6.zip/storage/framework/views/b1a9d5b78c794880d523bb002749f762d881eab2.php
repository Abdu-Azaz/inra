<?php $__env->startSection('pageTitle', 'Date et CR des réunions'); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-3 text-white animated zoomIn">Date et CR des réunions</p>
                <i class="fa fa-circle text-white px-2"></i>
                
            </div>
        </div>
    </div>
    </div>
    

    
    <div class="container">
        
        <div id="accordion" class="border border-primary">
            <?php $__currentLoopData = $meetingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header " id="heading-<?php echo e($year); ?>">
                        <button class="accordion-button collapsed text-dark" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapse-<?php echo e($year); ?>" aria-expanded="false"
                            aria-controls="collapse-<?php echo e($year); ?>">
                            <i class="fa fa-calendar me-2"> </i>
                            REUNIONS DE <?php echo e($year); ?>

                        </button>
                    </h2>
                    <div id="collapse-<?php echo e($year); ?>" class="accordion-collapse collapse"
                        aria-labelledby="heading-<?php echo e($year); ?>" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $meetings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item border border-primary my-1">
                                    <h2 class="accordion-header " id="heading-<?php echo e($year); ?>-<?php echo e($month); ?>">
                                        <button class="accordion-button collapsed text-dark" type="button"
                                            data-bs-toggle="collapse"
                                            data-bs-target="#collapse-<?php echo e($year); ?>-<?php echo e($month); ?>"
                                            aria-expanded="false"
                                            aria-controls="collapse-<?php echo e($year); ?>-<?php echo e($month); ?>">
                                            <?php echo e(Carbon\Carbon::createFromFormat('!m', $month)->format('F')); ?>

                                        </button>
                                    </h2>
                                    <div id="collapse-<?php echo e($year); ?>-<?php echo e($month); ?>"
                                        class="accordion-collapse collapse"
                                        aria-labelledby="heading-<?php echo e($year); ?>-<?php echo e($month); ?>"
                                        data-bs-parent="#collapse-<?php echo e($year); ?>">
                                        <div class="accordion-body">
                                            <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <ul class="list-group mb-2">
                                                    <li class="list-group-item"><span class="fw-bold"><i
                                                                class="fa fa-info-circle"></i> titre: </span> <span
                                                            class="text-primary fw-bold"><?php echo e($meeting->titre); ?></span></li>
                                                    <li class="list-group-item"><i class="fa fa-calendar"></i> <span
                                                            class="fw-bold"> date: </span> <span
                                                            class="text-primary fw-bold"><?php echo e(\Carbon\Carbon::parse($meeting->date)->format('d-m-Y')); ?></span>
                                                    </li>
                                                    <li class="list-group-item"><i class="fa fa-clock-o"></i> <span
                                                            class="fw-bold"> temps: </span> <span
                                                            class="text-primary fw-bold"><?php echo e($meeting->temps); ?></span></li>
                                               
                                                            <li
                                                            class=" list-group-item ">
                                                            <a class="fw-bold btn btn-outline-danger btn-sm rounded"
                                                                href="<?php echo e(url('storage/' . $meeting->fichier)); ?>"><i
                                                                    class="fa fa-file-pdf-o"
                                                                    aria-hidden="true"></i>  Voir PDF</a>
                                                        </li>
                                                </ul>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        // $(function() {
        // Define custom icons
        // var customIcons = {
        //     year: 'bi bi-calendar4-range',
        //     month: 'bi bi-calendar3',
        //     meeting: 'bi bi-calendar-check'
        // };

        // Define an array of month names
        // var monthNames = [
        //     '',
        //     'January', 'February', 'March', 'April', 'May', 'June',
        //     'July', 'August', 'September', 'October', 'November', 'December'
        // ];

        // Convert meetingData into jsTree format
        // var treeData = [];

        // Iterate over meetingData
        // <?php $__currentLoopData = $meetingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        //     var yearNode = {
        //         id: 'year_' + <?php echo e($year); ?>,
        //         text: '<?php echo e($year); ?>',
        //         icon: customIcons.year,
        //         children: []
        //     };

        // Iterate over months
        // <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $meetings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        //     var monthNode = {
        //         id: 'month_' + <?php echo e($year); ?> + '_' + <?php echo e($month); ?>,
        //         text: monthNames[<?php echo e($month); ?>],
        //         icon: customIcons.month,
        //         children: []
        //     };

        //             // // Iterate over meetings
        //             // <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        //             //     var meetingNode = {
        //                     id: 'meeting_' + <?php echo e($year); ?> + '_' + <?php echo e($month); ?> + '_' +
        //                         <?php echo e($loop->index); ?>,
        //                     text: '<?php echo e($meeting->titre); ?> date: <?php echo e($meeting->date); ?> ',
        //                     icon: customIcons.meeting
        //                 };

        //                 monthNode.children.push(meetingNode);
        //             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        //             yearNode.children.push(monthNode);
        //         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        //         treeData.push(yearNode);
        //     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        //     // Initialize jsTree with the converted data and custom icons
        //     $('#treeview').jstree({
        //         core: {
        //             data: treeData
        //         },
        //         types: {
        //             year: {
        //                 icon: customIcons.year
        //             },
        //             month: {
        //                 icon: customIcons.month
        //             },
        //             meeting: {
        //                 icon: customIcons.meeting
        //             }
        //         },
        //         plugins: ['types']
        //     });
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/management/reunions.blade.php ENDPATH**/ ?>