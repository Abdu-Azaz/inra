<?php $__env->startSection('pageTitle', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid bg-dark py-3 bg-header" style="margin-bottom: 70px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Convention de droit commun</p>
                <i class="bi bi-circle text-white px-2"></i>
                <h3 class="text-white animated zoomIn">
                    <span class="text-warning">
            </div>
        </div>
    </div>
    </div>



    <div class="container d-flex flex-column align-items-center justify-content-center ">

        <p class="lead text-dark fs-2 text-center">Mise en oeuvre des projets de recherche sur l'arganier dans
            le cadre du projet de <b>D</b>éveloppement de l'<b>A</b>rganiculture dans les zones Vulnérables <b> "DARED" </b>
            financé par le Fonds Vert pour le Climat</p>
        <a href="<?php echo e(route('contrat')); ?>" class="btn btn-primary py-md-3 px-md-5 me-3 animated"
            style="max-width:300px">CONVENTION DE DROIT COMMUN</a>

         
    </div>

    
    <!-- Facts Start -->
    
    <!-- Facts Start -->
    

    <table id="myTable" class="display">
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>City</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>John Doe</td>
            <td>25</td>
            <td>New York</td>
          </tr>
          <tr>
            <td>Jane Smith</td>
            <td>30</td>
            <td>London</td>
          </tr>
          <tr>
            <td>Mike Johnson</td>
            <td>35</td>
            <td>Tokyo</td>
          </tr>
        </tbody>
      </table>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/main.blade.php ENDPATH**/ ?>