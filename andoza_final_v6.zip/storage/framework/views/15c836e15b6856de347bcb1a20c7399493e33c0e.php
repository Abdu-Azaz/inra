<?php $__env->startSection('pageTitle', 'Gestion budget'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Gestion budget</p>
                <i class="fa fa-circle text-white px-2"></i>
                
            </div>
        </div>
    </div>
    </div>

    <div class="container">

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s"
                style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                <div
                    class="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center border border-3">
                    <div class="service-icon">
                        <i class="fa fa-money fs-1 text-white"></i>
                    </div>
                    <h4 class="mb-3"><?php echo e($budget->titre); ?></h4>
                    <p class="ms-0 text-dark fw-bold"> <span class="text-primary">Date:</span> <?php echo e($budget->date); ?></p>
                    <a class="btn btn-outline-danger btn-sm rounded" href="<?php echo e(url('storage/'.$budget->fichier)); ?>">
                        <i class="fa fa-file-pdf-o"></i>  Rapport
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/management/budgets.blade.php ENDPATH**/ ?>