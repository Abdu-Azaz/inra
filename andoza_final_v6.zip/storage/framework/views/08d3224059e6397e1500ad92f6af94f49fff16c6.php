
    <select name="chercheur_id">
        <?php $__currentLoopData = $supervisorOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><?php /**PATH /home/abdoo/andoza_ultimate/vendor/tcg/voyager/resources/views/formfields/chercheur_dropdown.blade.php ENDPATH**/ ?>