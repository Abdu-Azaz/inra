<textarea class="form-control richTextBox" name="<?php echo e($row->field); ?>" id="richtext<?php echo e($row->field); ?>">
    <?php echo e(old($row->field, $dataTypeContent->{$row->field} ?? '')); ?>

</textarea>

<?php $__env->startPush('javascript'); ?>
    
    <script>
        $(document).ready(function() {
            //     var additionalConfig = {
            //         selector: 'textarea.richTextBox[name="<?php echo e($row->field); ?>"]',
            //     }

            //     $.extend(additionalConfig, <?php echo json_encode($options->tinymceOptions ?? (object) []); ?>)

            //     tinymce.init(window.voyagerTinyMCE.getConfig(additionalConfig));


            new FroalaEditor('#richtext<?php echo e($row->field); ?>', {
                // Set a preloader.
                // imageManagerPreloader: "/images/loader.gif",

                // Set page size.
                imageManagerPageSize: 20,

                // Set a scroll offset (value in pixels).
                imageManagerScrollOffset: 10,

                // Set the load images request URL.
                imageManagerLoadURL: "<?php echo e(route('images')); ?>",
                imageManagerLoadMethod: "GET",
                imageManagerDeleteURL: '<?php echo e(route('image.delete', ['image' => '__image__'])); ?>',
                imageManagerDeleteMethod: 'DELETE',
                imageManagerDeleteParams: {
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                events: {
                    'imageManager.error': function(error, response) {
                        console.log('Image Manager Error:');
                        console.log('Error:', error);
                        console.log('Response:', response);
                    },


                    'imageManager.beforeDeleteImage': function($img) {
                        // Do something before deleting an image from the image manager.
                        alert('Image will be deleted.');
                        console.log($img.attr('src'));
                        // console.log($img.);

                    },

                    'imageManager.imageDeleted': function(image) {

                        console.log(image);

                    }
                }
            })
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/abdoo/andoza_ultimate/vendor/tcg/voyager/resources/views/formfields/rich_text_box.blade.php ENDPATH**/ ?>