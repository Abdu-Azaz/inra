<?php $__env->startSection('pageTitle', 'Publications '.$axe); ?>


<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Outputs / Publications</p>
                <i class="bi bi-circle text-white px-2"></i>
                <h3 class="text-white animated zoomIn">
                    <span class="text-warning">
                        
            </div>
        </div>
    </div>
    </div>
    <div class="section-title text-center position-relative pb-3 mb-4 mx-auto bg-white p-4 rounded" style="max-width: 600px;">
        <h1 class="mb-0">Publications</h1>
    </div>
    <div class="container">
        
        <?php if(empty(!$publications)): ?>
            <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <div
                        class="service-item bg-light d-flex flex-column align-items-center justify-content-center text-center border border-3">
                        <div class="service-icon">
                            <i class="fa fa-check-circle-o text-white fs-1"></i>
                        </div>
                        <h4 class=""><?php echo e($publication->titre); ?></h4>
                        <hr class="w-50 mx-auto bg-dark">

                        <p class="mb-1 text-dark fw-bold"> <span class="text-primary"></span> <?php echo e($publication->auteur); ?></p>
                        <?php if(isset($publication->fichier)): ?>
                            <a class="fw-bold btn btn-outline-danger  btn-sm" href="<?php echo e(url('storage/' . $publication->fichier)); ?>">
                                <i class="fa fa-file-pdf-o"></i> Rapport
                        </a>
                        <?php endif; ?>
                        <?php if(isset($publication->lien)): ?>
                            <a class="fw-bold text-danger" href="<?php echo e($publication->lien); ?>"
                                style="font-size: 1.2em">
                                <i class="fa fa-link"></i> Lien
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        <?php else: ?>
            Pas de publications pour le moment
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/outputs/publications.blade.php ENDPATH**/ ?>