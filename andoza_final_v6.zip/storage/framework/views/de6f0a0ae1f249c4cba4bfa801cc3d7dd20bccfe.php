<?php $__env->startSection('pageTitle', 'Gallery'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid bg-dark py-3 bg-header" style="margin-bottom: 70px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Gallery</p>
                <i class="bi bi-circle text-white px-2"></i>
                <h3 class="text-white animated zoomIn">
                    <span class="text-warning">
            </div>
        </div>
    </div>
    </div>

    <div class="container">
        <div class="row">
            
            <?php $__currentLoopData = \App\Models\Gallery::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $extension = pathinfo($item->image, PATHINFO_EXTENSION);
                    $isImage = in_array($extension, ['jpg', 'jpeg', 'png', 'gif']);
                    $isVideo = in_array($extension, ['mp4', 'mov', 'avi']);
                ?>
                <div class="col-lg-4">
                    <div class="blog-item position-relative overflow-hidden border border">
                        <?php if($isImage): ?>
                            <a href="<?php echo e(url('storage/' . $item->image)); ?>" data-lightbox="x"
                                data-title="<?php echo e($item->title); ?>">
                                <img class="img-fluid" src="<?php echo e(url('storage/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>">
                                <div class="blog-overlay">
                                    <p class="text-white"><?php echo e($item->title); ?></p>
                                </div>
                                 
                            </a>
                            
                        <?php elseif($isVideo): ?>
                            <a href="<?php echo e(url('storage/' . $item->image)); ?>" data-lightbox="x"
                                data-title="<?php echo e($item->title); ?>" data-href="<?php echo e(url('storage/' . $item->image)); ?>">
                                <video controls class="w-100" poster="<?php echo e(url('storage/' . $item->image)); ?>">
                                    <source  src="<?php echo e(url('storage/' . $item->image)); ?>" type="video/mp4">
                                </video>
                            </a>
                            
                        <?php endif; ?>
                        
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/gallery.blade.php ENDPATH**/ ?>