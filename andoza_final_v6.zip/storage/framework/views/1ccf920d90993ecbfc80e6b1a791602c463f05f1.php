<?php $__env->startSection('pageTitle', 'Méthodologies : Site 1'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
    <div class="row py-5">
        <div class="col-12 pt-lg-5 mt-lg-5 text-center">
            <p class="display-3 text-white animated zoomIn"><?php echo e($sitename); ?></p>
            <i class="fa fa-map text-white px-2"></i>
        </div>
    </div>
</div>
</div>


<div class="container">    
    <div class="d-flex justify-content-center mb-5">
        <?php if(isset($map_embed->embed)): ?>
        <?php echo $map_embed->embed; ?>

        <?php endif; ?>
    </div>
    <?php if(isset($map_embed->embed)): ?>
        <?php echo $map_embed->description; ?>

        <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/methodologies/site.blade.php ENDPATH**/ ?>