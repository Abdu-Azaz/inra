<div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
    <div class="row py-5">
        <div class="col-12 pt-lg-5 mt-lg-5 text-center">
            <h1 class="display-4 text-white animated zoomIn">Résultats / <?php echo e($rapports[0]->axe); ?></h1>
            <i class="bi bi-circle text-white px-2"></i>
            <h3 class="text-white animated zoomIn">Titre: <?php echo e($titre_axe->titre_axe); ?></h3>
        </div>
    </div>
</div><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/partials/page_header.blade.php ENDPATH**/ ?>