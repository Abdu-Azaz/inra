<?php $__env->startSection('pageTitle', 'Resultats : ' . $axe['axe']); ?>


<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Résultats / <?php echo e($axe['axe']); ?> </p>
                <i class="bi bi-circle text-white px-2"></i>
                <h3 class="text-white animated zoomIn">
                    <span class="text-warning">
                        <?php if(empty($axe['axe_title'])): ?>
                            Entrer un titre pour <?php echo e($axe['axe']); ?>

                        <?php else: ?>
                        Titre: 
                            <?php echo e($axe['axe_title']->titre_axe); ?>

                        <?php endif; ?>
                    </span></h3>
            </div>
        </div>
    </div>
    </div>
    <div class="section-title text-center position-relative pb-3 mb-4 mx-auto bg-white p-4 rounded" style="max-width: 600px;">
        <h1 class="mb-0">Les rapports</h1>
        
    </div>
    <div class="container">
        
        <?php if(empty(!$rapports)): ?>
            <?php echo $__env->make('partials.resultats_axe_template', ['rapports' => $rapports], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            Pas de rapports pour le moment
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/resultats/axe.blade.php ENDPATH**/ ?>