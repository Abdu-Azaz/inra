<?php $__env->startSection('pageTitle', 'Fiches Techniques / '.$axe); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-4 text-white animated zoomIn">Outputs / Fiches Techniques </p>
                <i class="bi bi-circle text-white px-2"></i>
                <h3 class="text-white animated zoomIn">
                    <span class="text-warning">
            </div>
        </div>
    </div>
    </div>
    <div class="section-title text-center position-relative pb-3 mb-4 mx-auto bg-white p-4 rounded" style="max-width: 600px;">
        <h3 class="mb-0">Fiches techniques (<?php echo e($axe); ?>)</h3>
    </div>
    <div class="container">
        
        <?php if(empty( !$fiches)): ?>
            <?php $__currentLoopData = $fiches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fiche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 wow slideInUp " data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: slideInUp;">
                    <div class="team-item bg-light rounded overflow-hidden border border-primary">
                        <div class="team-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="<?php echo e(url('storage/' . $fiche->image)); ?>"
                                alt="<?php echo e(url($fiche->titre)); ?>">
                            <div class="team-social">
                                <a class="btn btn-sm btn-secondary rounded px-2"
                                    href="<?php echo e(url('storage/' . $fiche->fichier)); ?>">Visualiser la fiche</a>
                            </div>
                        </div>
                        <div class="text-center py-4 bg-white">
                            <h5 class="text-primary text-uppercase"><?php echo e($fiche->titre); ?></h5>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        <?php else: ?>
            Pas de fiches pour le moment
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/outputs/fiches.blade.php ENDPATH**/ ?>