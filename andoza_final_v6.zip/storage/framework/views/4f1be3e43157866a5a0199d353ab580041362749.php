<?php
    // if(!empty($axe['axe']))
    $pageTitle = 'Méthodologies : ' . $axe['axe'];
    // else
    // $pageTitle = 'Méthodologies : ' . $axe['axe'];
?>

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-3 text-white animated zoomIn">Méthodologies |
                    <?php echo e($axe['axe']); ?>

                </p>
                <i class="fa fa-circle text-white px-2"></i>
                <h4 class="text-white animated zoomIn">Titre Axe:
                    <span class="text-warning">
                        <?php if(empty($axe['axe_title'])): ?>
                            <?php echo e($axe['axe']); ?>

                        <?php else: ?>
                            <?php echo e($axe['axe_title']->titre_axe); ?>

                        <?php endif; ?>
                    </span>
                </h4>
                
            </div>
        </div>
    </div>
    </div>
    <div class="container">
        
        <div class="section-title text-center position-relative pb-3 mb-4 mx-auto bg-white p-2 rounded "
            style="max-width: 600px;">
            <h3 class="mb-0">Activités
            </h3>
        </div>
        <h3>Sommaire</h3>
        <?php if(empty($activities)): ?>
            Pas d'activités pour le moment
        <?php else: ?>
            <ul class="list-groupe bg-light p-4 border border-2">
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-geroup-item fw-bold"><a href="#<?php echo e($loop->index + 1); ?>"><?php echo e($activity->titre); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container my-5">
            <section id="<?php echo e($loop->index + 1); ?>" class="bg-light border border-2 p-4 rounded " style="min-height:100vh">
                <h2><?php echo e($activity->titre); ?></h2>
                <p style="font-size: 1.25rem;"><?php echo $activity->corps; ?></p>
            </section>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/methodologies/axe.blade.php ENDPATH**/ ?>