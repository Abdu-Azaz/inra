    <div class="container">
        <div id="accordion" class="border border-primary">
            <?php $__currentLoopData = $rapports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $groupedRapportsByYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header " id="heading-<?php echo e($year); ?>">
                        <button class="accordion-button collapsed text-dark" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapse-<?php echo e($year); ?>" aria-expanded="false"
                            aria-controls="collapse-<?php echo e($year); ?>">
                            RAPPORTS DE <?php echo e($year); ?>

                        </button>
                    </h2>
                    <div id="collapse-<?php echo e($year); ?>" class="accordion-collapse collapse"
                        aria-labelledby="heading-<?php echo e($year); ?>" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            <div class="accordion border border-primary" id="subAccordion-<?php echo e($year); ?>">
                                <?php $__currentLoopData = $groupedRapportsByYear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportType => $groupedRapports): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header"
                                            id="heading-<?php echo e($year); ?>-<?php echo e($reportType); ?>">
                                            <button class="accordion-button collapsed  text-dark" type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target="#collapse-<?php echo e($year); ?>-<?php echo e($reportType); ?>"
                                                aria-expanded="false"
                                                aria-controls="collapse-<?php echo e($year); ?>-<?php echo e($reportType); ?>">
                                                <?php echo e(strtoupper($reportType)); ?>S
                                            </button>
                                        </h2>
                                        <div id="collapse-<?php echo e($year); ?>-<?php echo e($reportType); ?>" class="collapse"
                                            aria-labelledby="heading-<?php echo e($year); ?>-<?php echo e($reportType); ?>"
                                            data-bs-parent="#subAccordion-<?php echo e($year); ?>">
                                            <div class="accordion-body ">
                                                <?php $__currentLoopData = $groupedRapports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rapport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <ul class="list-group bg-primary mb-2 border border-2 border-dark">
                                                        <li class="fw-bold text-dark list-group-item"> <i
                                                                class="fa fa-book"></i> Titre rapport:<span
                                                                class="text-decoration-underline">
                                                                <?php echo e($rapport->titre); ?></span></li>
                                                        <li class="fw-bold text-dark list-group-item"> <i
                                                                class="fa fa-calendar"></i> Date: <span
                                                                class="text-decoration-underline">
                                                                <?php echo e(\Carbon\Carbon::parse($rapport->date)->format('d-m-Y')); ?></span>
                                                        </li>
                                                        <li
                                                            class=" list-group-item ">
                                                            <a class="fw-bold btn btn-outline-danger btn-rounded btn-sm"
                                                                href="<?php echo e(url('storage/' . $rapport->fichier)); ?>"><i
                                                                    class="fa fa-file-pdf-o"
                                                                    aria-hidden="true"></i>  Voir PDF</a>
                                                        </li>
                                                    </ul>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>
<?php /**PATH /home/abdoo/andoza_ultimate/resources/views/partials/resultats_axe_template.blade.php ENDPATH**/ ?>