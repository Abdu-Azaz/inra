<?php
    $type = $type === 'pfe' ? 'PFE' : 'Doctorants';
?>
<?php $__env->startSection('pageTitle', $type); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-dark py-5 bg-header" style="margin-bottom: 90px;">
        <div class="row py-5">
            <div class="col-12 pt-lg-5 mt-lg-5 text-center">
                <p class="display-3 text-white animated zoomIn"><?php echo e($type); ?></p>
                <i class="fa fa-circle text-white px-2"></i>
            </div>
        </div>
    </div>
    </div>
    <div class="container">

        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stagiaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 wow slideInUp " data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: slideInUp;">
                    <div class="team-item  overflow-hidden border border-3">
                        <div class="team-img position-relative overflow-hidden">
                            <?php if(isset($stagiaire->photo)): ?>
                                <img class="img-fluid w-100" src="<?php echo e(url('storage/' . $stagiaire->photo)); ?>"
                                alt="<?php echo e($stagiaire->full_name); ?>">
                            <?php else: ?>
                                <img class="img-fluid w-100" src="<?php echo e(url('img/avatar.png')); ?>"
                                alt="<?php echo e($stagiaire->full_name); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="text-center py-2 bg-light">
                            <h5 class="text-primary text-uppercase"><?php echo e($stagiaire->full_name); ?></h5>
                            <h6 class="text-uppercase  text-dark"><?php echo e($stagiaire->type); ?></h6>
                            <hr class="w-50 mx-auto bg-dark my-2">
                            <h6 class="text-uppercase  text-dark"><?php echo e($stagiaire->axe); ?></h6>
                            <?php if(isset($stagiaire->soutenu_le)): ?>
                            <h6 class="text-dark">Soutenu le: <?php echo e(\Carbon\Carbon::parse($stagiaire->soutenu_le)->format('d-m-Y')); ?></h6>
                            <?php endif; ?>
                            <?php if(isset($stagiaire->fichier)): ?>
                                <a class="btn btn-sm btn-outline-danger fw-bold" href="<?php echo e(url('storage/' . $stagiaire->fichier)); ?>"><i class="fa fa-file-pdf-o"></i> Rapport</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdoo/andoza_ultimate/resources/views/management/thesards.blade.php ENDPATH**/ ?>